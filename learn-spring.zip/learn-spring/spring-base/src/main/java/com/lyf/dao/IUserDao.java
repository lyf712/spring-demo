package com.lyf.dao;

import com.lyf.dao.domain.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IUserDao {

    void addOne(User user);


}
