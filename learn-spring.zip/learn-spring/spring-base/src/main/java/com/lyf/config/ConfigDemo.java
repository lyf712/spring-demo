package com.lyf.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(value = "com.lyf.config")
@PropertySource("")
public class ConfigDemo {

    @Bean
    void config1(){
        System.out.println("这是一个config测试...");
    }


}
