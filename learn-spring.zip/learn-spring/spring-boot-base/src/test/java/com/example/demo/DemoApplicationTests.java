package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}


	@Test
	void testRedis(){
//		JedisPool jedisPool = new JedisPool();
//
//
//		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
//  jedisPoolConfig.setMaxIdle(8);

		//Jedis jedis = new Jedis("182.92.65.135",6379);

		// 1.连接池
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		jedisPoolConfig.setMaxIdle(8);
		jedisPoolConfig.setMaxIdle(20);
		jedisPoolConfig.setMaxWaitMillis(10);

		JedisPool jedisPool = new JedisPool("182.92.65.135",6379);
		Jedis jedis = null ;
		jedis = jedisPool.getResource();
		System.out.println(jedis.get("name"));


	}

}
