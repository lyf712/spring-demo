package com.example.demo.config;


import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ShiroConfig {

    @Bean
    @ConditionalOnMissingBean
    //实现spring的自动代理
    //https://blog.csdn.net/daryl715/article/details/1621610
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator(){
        DefaultAdvisorAutoProxyCreator defaultAAp = new DefaultAdvisorAutoProxyCreator();
        defaultAAp.setProxyTargetClass(true);
        return defaultAAp;
    }




}
