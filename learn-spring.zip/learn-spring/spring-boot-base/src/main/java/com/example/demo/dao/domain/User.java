package com.example.demo.dao.domain;

public class User {
}
