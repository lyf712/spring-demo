package com.example.demo.dao.impl;

import com.example.demo.dao.mapper.PersonMapper;
import com.example.demo.jpa.domain.Person;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PersonImpl implements PersonMapper {

    @Override
    public List<Person> queryAll() {
        return null;
    }
}
