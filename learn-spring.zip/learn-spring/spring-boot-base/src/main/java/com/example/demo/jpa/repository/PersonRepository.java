package com.example.demo.jpa.repository;

import com.example.demo.jpa.domain.Person;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonRepository extends JpaRepository<Person,Long> {

    Person queryByName(String name);



}
