package com.example.demo.service.impl;

import com.example.demo.jpa.domain.Person;
import com.example.demo.jpa.repository.PersonRepository;
import com.example.demo.service.IPersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PersonService implements IPersonService {

    @Autowired
    PersonRepository personRepository;

    // @Transactional()
    @Transactional(rollbackFor = {IllegalArgumentException.class})
    @CachePut(value = "people",key="#person.id")
    public void save(Person person){

        if(person.getName().equals("李云飞"))
        {
            throw new IllegalArgumentException("李云飞已存在,数据将回滚..");
        }

        personRepository.save(person);

    }

    @Override
    public Person queryByName(String name) {
        personRepository.queryByName(name);
        return null;
    }


}
