package com.example.demo.controller;

import com.example.demo.dao.IUserDao;
import com.example.demo.dao.mapper.PersonMapper;
import com.example.demo.jpa.domain.Person;
import com.example.demo.jpa.repository.PersonRepository;
import com.example.demo.service.impl.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/Test")
public class TestController {

    @Value("${name}")
    private String myName;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    PersonRepository personRepository;


    @Autowired
    PersonService personService;

//    @Autowired
//    RedisTemplate redisTemplate;

    @Autowired
    PersonMapper  personMapper;

  //  @Value("#{systemProperties.user.name}")
    //private String sysInfo;
//
//    @Value("#{systemEnvironment.user.name}")
//    private String sysInfo;

    @RequestMapping("/test1")
    @ResponseBody
    public String test1(){

        System.out.println(personRepository.queryByName("李云飞"));
        return "hello!"+myName+";";
    }

    @RequestMapping

    public String test2(){

       personService.save(new Person(null,"lyf",14));

     //  redisTemplate.opsForValue().get(1);

        return "";
    }



}
