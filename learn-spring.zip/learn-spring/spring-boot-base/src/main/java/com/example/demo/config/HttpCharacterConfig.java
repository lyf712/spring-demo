package com.example.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;

@Component
// 配置编码
@ConfigurationProperties(prefix = "server.servlet.encoding")
public class HttpCharacterConfig {

    public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");

    private Charset charset = DEFAULT_CHARSET;

    private boolean force = true;


    public void setCharset(Charset charset){
        this.charset =charset;
    }
    public Charset getCharset(){
        return this.charset;
    }

    public boolean isForce(){
        return this.force;
    }

    public void setForce(boolean force){
        this.force = force;
    }

}
