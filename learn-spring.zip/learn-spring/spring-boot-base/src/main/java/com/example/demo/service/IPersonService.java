package com.example.demo.service;

import com.example.demo.jpa.domain.Person;

public interface IPersonService {

    public void save(Person person);

    public Person queryByName(String name);

}
