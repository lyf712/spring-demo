package com.lyf.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;

import javax.persistence.Access;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	RedisTemplate redisTemplate;

	@Autowired
	StringRedisTemplate stringRedisTemplate;


	@Test
	void contextLoads() {


	}

	@Test
	void redisTest(){
		System.out.println(stringRedisTemplate.opsForValue().get("people::1"));
	}
}
