package com.lyf.service;

import com.lyf.sdk.Sms;
import org.junit.Test;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class SmsService {

    private String code;

   @Test
    public void sendMsg(){
      ;
        Sms sms = new Sms();
        sms.sendSms(this.randomCode());
       // for(int i =0;i<10;i++)
        System.out.println("业务层发送短信,验证码为:"+this.code);

        try{
            Thread.sleep(60000);//延迟60s

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

   }

    @Test
    public void validate(){
        System.out.println(this.code);
        String userInput ="0055";
        System.out.println("开始短信验证...");


       // String code = "3132";//随机产生

       // this.sendMsg();

        if(userInput.equals(this.code)){
            System.out.println("验证成功！！");

          //  return true;
        }
//        return false;

    }

    public String randomCode(){
        Random random = new Random();

        this.code = random.nextInt(9)+""+
                random.nextInt(9)+ random.nextInt(9)+
                random.nextInt(9);

        System.out.println("random产生随机码为"+this.code);
        return this.code;
    }



}
