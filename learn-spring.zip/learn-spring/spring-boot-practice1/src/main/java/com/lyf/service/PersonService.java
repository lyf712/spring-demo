package com.lyf.service;

import com.lyf.dao.domain.Person;

public interface PersonService {

    void handleAll();

    void save(Person peron);

    String findOneById(int id);

    void deleteById(int id);

}
