package com.lyf.controller;

import com.lyf.service.SmsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SmsController {

    @Autowired
    SmsService smsService;

    @RequestMapping(value = "/sendMsg",method = RequestMethod.POST)
    public void sendMsg(){

    }


    @RequestMapping(value = "/validateSms",method = RequestMethod.POST)
    public boolean isValidated(String input){

//        if(smsService.validate(input)){
//
//            return true;
//        }

        return false;
    }


}
