package com.lyf.dao.impl;

import com.lyf.dao.PersonDao;
import com.lyf.dao.domain.Person;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PersonDaoImpl implements PersonDao {


    @Override
    public List<Person> queryAll() {
        return null;
    }

    @Override
    public void save(Person person) {

    }

    @Override
    public Person queryById(int id) {
        return null;
    }

    @Override
    public void deletePerson(int id) {

    }
}
