package com.lyf.controller;


import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Consumer")
@RabbitListener(queues = "queue-test")
public class MsgConsumerController {

    @RabbitHandler
    @RequestMapping("/receive")
    public void process(String info){
        System.out.println("process1从queue-test中收到"+info);
    }


}
