package com.lyf.controller;

import com.lyf.dao.domain.Person;
import com.lyf.dao.jpa.Person2Repository;
import com.lyf.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/Test")
public class TestController {

    @Autowired
    JdbcTemplate jdbcTemplate; // 源代码: jdbcTemplate(DataSource dataSource, JdbcProperties properties)
    @Autowired
    PersonService personService;
    @Autowired
    Person2Repository personRepository;
    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    StringRedisTemplate stringRedisTemplate;



    // 测试jdbcTemplate
    @RequestMapping(value = "/test1",method = RequestMethod.GET)
    @ResponseBody
    public String test1(){
        System.out.println("进入test1Controller 。。");
        String sql ="SELECT * FROM person";
        // 进行RowMapper封装
        RowMapper<Person> rowMapper = new BeanPropertyRowMapper<Person>(Person.class);
        List<Person> people = jdbcTemplate.query(sql,rowMapper);
        for(Person p :people){
            System.out.println(p);
        }
        return "this is a test";
    }

    // 测试mybatis的mapper的使用
    @RequestMapping(value = "/test2",method = RequestMethod.GET)
    @ResponseBody
    public String test2(){
        System.out.println("控制层开始处理...");
        personService.handleAll();
        return "处理OK";
    }

    // 测试jpa
    @RequestMapping(value = "/test3",method = RequestMethod.GET)
    @ResponseBody
    public String test3(){
        System.out.println("控制层开始处理...");
       // personService.handleAll();
        System.out.println("count的使用:"+personRepository.count());
        return "处理OK";
    }

    // 测试jpa
    @RequestMapping(value = "/test4",method = RequestMethod.GET)
    @ResponseBody
    public String test4(){
        System.out.println("控制层开始处理...");
        // personService.handleAll();
        System.out.println("结果:"+redisTemplate.opsForValue().get("name")+stringRedisTemplate.opsForValue().get("name")); //结果:nulltestName

        return "处理OK";
    }


    // 测试cache
    @RequestMapping(value = "/test5",method = RequestMethod.GET)
    @ResponseBody
    public String test5(){
        System.out.println("控制层开始处理...");
        // personService.handleAll();
    //    System.out.println("结果:"+redisTemplate.opsForValue().get("name")+stringRedisTemplate.opsForValue().get("name")); //结果:nulltestName

      //  personService.save(new Person(null,"吴伟",18));
        personService.findOneById(1);


        return "处理OK";
    }






}
