package com.lyf.controller;

import com.lyf.dao.domain.Person;
import com.lyf.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/RedisTest")
public class RedisCacheController {

    @Autowired
    PersonService personService;


    @RequestMapping("/update")
    @ResponseBody
    void updateUser(Person person){
        personService.save(person);
        System.out.println("控制层添加了person");
    }

    @RequestMapping("/query")
    @ResponseBody
    void queryUser(int id){
        personService.findOneById(id);
        System.out.println("控制层查询了person");
    }

    @RequestMapping("/delete")
    @ResponseBody
    void deleteUser(int id){
        personService.deleteById(id);
        System.out.println("控制层删除了person");
    }


}
