package com.lyf.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Person2Repository extends JpaRepository<Person2,Long> {
}
