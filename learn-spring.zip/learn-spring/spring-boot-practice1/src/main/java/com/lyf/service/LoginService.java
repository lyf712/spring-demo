package com.lyf.service;

import com.lyf.dao.domain.User;

public interface LoginService {

    User getUserByName(String userName);

}
