package com.lyf.shiro;

import com.lyf.dao.domain.User;
import com.lyf.service.LoginService;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

public class UserRealm extends AuthorizingRealm {

    @Autowired
    private LoginService loginService;

    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        // 获取登录名
        String name = (String) principalCollection.getPrimaryPrincipal();
        // 查询用户
        User user = loginService.getUserByName(name);

        // 添加角色和权限
        SimpleAuthorizationInfo simpleAuthorizationInfo = new SimpleAuthorizationInfo();

//        for(Role role: usr.getRoles()){
//            simpleAuthorizationInfo.addRole(role.getRoleName());
//
//            // 添加权限
//            for(Permissions permissions:role.getPermissions()){
//                // 添加的权限名称（也可权限对象）
//                simpleAuthorizationInfo.addStringPermission(permissions.getPermissionName());
//            }
//
//        }

        return simpleAuthorizationInfo;
    }

    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {

        if(StringUtils.isEmpty(authenticationToken.getPrincipal()))
        {
            return null;
        }

        // 获取登录名
        String name = authenticationToken.getPrincipal().toString();

        User user = loginService.getUserByName(name);

        if(user == null)
        {
            return null;
        }else {

            SimpleAuthenticationInfo simpleAuthenticationInfo = new SimpleAuthenticationInfo(name,user.getPassword(),getName());
            return simpleAuthenticationInfo;
        }


      //  return null;
    }
}
