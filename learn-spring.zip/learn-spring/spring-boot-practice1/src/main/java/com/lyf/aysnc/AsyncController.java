package com.lyf.aysnc;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/async")
public class AsyncController {

    @Autowired
    AsyncService asyncService;
    @RequestMapping("/doTask")
    public String doTask(){
         for(int i =0 ;i<10;i++){
             asyncService.executeAsyncTask1(i);
             asyncService.executeAsyncTask2(i);
         }
        return "success";
    }

}
