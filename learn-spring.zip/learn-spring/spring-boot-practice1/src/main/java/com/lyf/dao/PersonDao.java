package com.lyf.dao;

import com.lyf.dao.domain.Person;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
//@Repository
public interface PersonDao {


    @Select("SELECT * FROM person")
    List<Person> queryAll();

    @Insert("INSERT INTO person VALUES(null,#{name},#{age})")
    void save(Person person);

    @Select("SELECT * FROM person WHERE id = #{id}")
    Person queryById(int id);

    @Delete("DELETE FROM person where id = #{id}")
    void deletePerson(int id);


}
