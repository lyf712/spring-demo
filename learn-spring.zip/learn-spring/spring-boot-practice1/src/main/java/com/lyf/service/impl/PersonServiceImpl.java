package com.lyf.service.impl;

import com.lyf.dao.PersonDao;
import com.lyf.dao.domain.Person;
import com.lyf.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    PersonDao personDao;


    @Override
    public void handleAll() {
        System.out.println("业务层开始处理查询所有用户的业务...,并开始打印");
        List<Person> list = personDao.queryAll();
        for(Person p :list){
            System.out.println(p);
        }
        System.out.println("业务层处理结束.");
    }

    // 更新缓存
    @CachePut(value = "people",key="#result.id")  //只能是result
    @Override
   // @Transactional()
    public void save(Person peron) {
        personDao.save(peron);
        System.out.println(peron+"在业务层做了缓存..");
    }


    @Override
    // 放入缓存
    @Cacheable(value = "people",key="#id")
    public String findOneById(int id) {
        Person person = personDao.queryById(id);
        return person.toString();
    }


    @Override
    @CacheEvict(value = "people",key = "#id")
    public void deleteById(int id) {

        System.out.println("在业务层删除了people的缓存..");
        personDao.deletePerson(id);
    }




}
