package com.lyf.dao.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
// 数据对应名字一致，否则报错 Table 'spring.person2' doesn't exist
public class Person2 {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private Integer age;


}
