package com.lyf.service.impl;

import com.lyf.dao.domain.User;
import com.lyf.service.LoginService;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {

    @Override
    public User getUserByName(String userName) {
        return null;
    }


}
