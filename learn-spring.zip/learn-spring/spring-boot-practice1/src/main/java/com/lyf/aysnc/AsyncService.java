package com.lyf.aysnc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * @Description: 创建线程任务服务
 * @ClassName: AsyncService
 * @Author: LYF
 * @Date: 2020年11月21日 下午2:54:32
 */

@Service
public class AsyncService {

    private Logger logger = LoggerFactory.getLogger(AsyncService.class);

   /**
   * @Description:通过@Async注解表明该方法是一个异步方法，
   * 如果注解在类级别上，则表明该类所有的方法都是异步方法，而这里的方法自动被注入使用ThreadPoolTaskExecutor作为TaskExecutor
   * @Title: executeAysncTask1
   * @Date: 2020年11月21日 下午2:54:32
   * @Author: LYF
   * @Throws
   * @param i
   */

   @Async
    public void executeAsyncTask1(Integer i){
       logger.info("AsyncService => executeAsyncTask1 method"+i);
   }

    @Async
    public void executeAsyncTask2(Integer i){
        logger.info("AsyncService => executeAsyncTask2 method"+i);
    }





}
