package com.lyf.service;

public interface UserService {
    public void addUser();
}
