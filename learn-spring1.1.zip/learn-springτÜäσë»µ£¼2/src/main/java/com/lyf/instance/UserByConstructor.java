package com.lyf.instance;

public class UserByConstructor {

    // 空着

//    public UserByConstructor(){
//
//    }


    public void print(){
        System.out.println("this is constructor test>");
    }
}
