package com.lyf.bankdemo.service;

public interface AccountService {
 public void transfer(String outUser,String inUser,int money);
}
