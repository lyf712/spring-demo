package com.lyf.dao;

public interface UserDao {
    public void add();
}
