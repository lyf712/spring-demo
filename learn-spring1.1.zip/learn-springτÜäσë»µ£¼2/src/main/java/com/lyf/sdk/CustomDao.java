package com.lyf.sdk;

public interface CustomDao {
    public void add();
    public void delete();
    public void query();
}
