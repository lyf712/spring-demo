package com.lyf.assembly.annotation.service;

public interface GoodsService {

    public void addGoods();
    public void deleteGoods();
}
