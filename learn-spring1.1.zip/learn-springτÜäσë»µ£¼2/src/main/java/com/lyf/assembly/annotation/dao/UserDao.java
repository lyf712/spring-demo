package com.lyf.assembly.annotation.dao;

public interface UserDao {
    public void add();
}
