package com.lyf.assembly.annotation.service;

public interface UserService {
    public void add();
}
