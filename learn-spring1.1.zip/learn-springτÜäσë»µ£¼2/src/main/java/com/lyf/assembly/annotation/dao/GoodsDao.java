package com.lyf.assembly.annotation.dao;

public interface GoodsDao {
    public void addGoods();
    public void deleteGoods();

}
