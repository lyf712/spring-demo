package com.lyf.assembly.annotation.controller;

import org.springframework.stereotype.Controller;

@Controller("goodsController")
public class GoodsController {

}
