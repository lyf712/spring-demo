////package com.lyf.web.dao.impl;
//
//import com.lyf.dao.entity.User;
//import com.lyf.web.dao.UserDao;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository("userDao")
//public class UserDaoImpl implements UserDao {
//
//
//
//
//    @Override
//    public void addOne(User user) {
//
//    }
//
//    @Override
//    public List<User> getAllUser() {
//        return null;
//    }
//}
